/!\ Important /!\


Afin de faciliter au mieux la phase d'évaluation, veuillez suivre les intructions suivantes :

 - Implémentez les différentes fonctions demandées dans un fichier projet.ml
 - Séparez les tests de vos fonctions dans un autre fichier .ml (par exemple main.ml)


Pour charger le module Dag, deux possibilités : 

 - passez le fichier dag.cma en paramètre de ocaml, au même titre que graph.cma
 OU
 - Tapez   #load "dag.cma";;   dans l'interface ocaml

