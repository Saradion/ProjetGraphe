open Projet
open Testproj
open Dag_test

let tritop_dag1 = tri_topologique (Dag.Dag.copy dag1);;
let tritop_dag2 = tri_topologique (Dag.Dag.copy dag2);;
let tritop_dag3 = tri_topologique (Dag.Dag.copy dag3);;
let tritop_dag4 = tri_topologique (Dag.Dag.copy dag4);;

Format.printf "Tri topologique\n";;
Format.printf "tri_topologique dag1;;\n";;
TestProjet.affiche_list tritop_dag1;;
TestProjet.verif_tri_topo dag1 tritop_dag1;;

Format.printf "tri_topologique dag2;;\n";;
TestProjet.affiche_list tritop_dag2;;
TestProjet.verif_tri_topo dag2 tritop_dag2;;

Format.printf "tri_topologique dag3;;\n";;
TestProjet.affiche_list tritop_dag3;;
TestProjet.verif_tri_topo dag3 tritop_dag3;;

Format.printf "tri_topologique dag4;;\n";;
TestProjet.affiche_list tritop_dag4;;
TestProjet.verif_tri_topo dag4 tritop_dag4;;




let ordomulti3_dag1 = ordonnanceur_multi 3 (Dag.Dag.copy dag1);;
let ordomulti3_dag2 = ordonnanceur_multi 3 (Dag.Dag.copy dag2);;
let ordomulti3_dag3 = ordonnanceur_multi 3 (Dag.Dag.copy dag3);;
let ordomulti3_dag4 = ordonnanceur_multi 3 (Dag.Dag.copy dag4);;

Format.printf "Ordonnancement non pondéré avec ressources multiples (3 ressources)\n";;
Format.printf "ordonnanceur_multi 3 dag1;;\n";;
TestProjet.affiche_trace ordomulti3_dag1;;
TestProjet.verif_ordo_multi 3 dag1 ordomulti3_dag1;;

Format.printf "ordonnanceur_multi 3 dag2;;\n";;
TestProjet.affiche_trace ordomulti3_dag2;;
TestProjet.verif_ordo_multi 3 dag2 ordomulti3_dag2;;

Format.printf "ordonnanceur_multi 3 dag3;;\n";;
TestProjet.affiche_trace ordomulti3_dag3;;
TestProjet.verif_ordo_multi 3 dag3 ordomulti3_dag3;;

Format.printf "ordonnanceur_multi 3 dag4;;\n";;
TestProjet.affiche_trace ordomulti3_dag4;;
TestProjet.verif_ordo_multi 3 dag4 ordomulti3_dag4;;



let ordomulti4_dag1 = ordonnanceur_multi 4 (Dag.Dag.copy dag1);;
let ordomulti4_dag2 = ordonnanceur_multi 4 (Dag.Dag.copy dag2);;
let ordomulti4_dag3 = ordonnanceur_multi 4 (Dag.Dag.copy dag3);;
let ordomulti4_dag4 = ordonnanceur_multi 4 (Dag.Dag.copy dag4);;

Format.printf "Ordonnancement non pondéré avec ressources multiples (4 ressources)\n";;
Format.printf "ordonnanceur_multi 4 dag1;;\n";;
TestProjet.affiche_trace ordomulti4_dag1;;
TestProjet.verif_ordo_multi 4 dag1 ordomulti4_dag1;;

Format.printf "ordonnanceur_multi 4 dag2;;\n";;
TestProjet.affiche_trace ordomulti4_dag2;;
TestProjet.verif_ordo_multi 4 dag2 ordomulti4_dag2;;

Format.printf "ordonnanceur_multi 4 dag3;;\n";;
TestProjet.affiche_trace ordomulti4_dag3;;
TestProjet.verif_ordo_multi 4 dag3 ordomulti4_dag3;;

Format.printf "ordonnanceur_multi 4 dag4;;\n";;
TestProjet.affiche_trace ordomulti4_dag4;;
TestProjet.verif_ordo_multi 4 dag4 ordomulti4_dag4;;



let ordohete10_2_2_dag1 = ordonnanceur_heterogene 10.0 2 2 (Dag.Dag.copy dag1);;
let ordohete10_2_2_dag2 = ordonnanceur_heterogene 10.0 2 2 (Dag.Dag.copy dag2);;
let ordohete10_2_2_dag3 = ordonnanceur_heterogene 10.0 2 2 (Dag.Dag.copy dag3);;
let ordohete10_2_2_dag4 = ordonnanceur_heterogene 10.0 2 2 (Dag.Dag.copy dag4);;

Format.printf "Ordonnancement hétérogène pondéré\n";;
Format.printf "ordonnanceur_heterogene 10.0 2 2 dag1;;\n";;
TestProjet.affiche_trace ordohete10_2_2_dag1;;
TestProjet.verif_ordo_heterogene 10.0 2 2 dag1 ordohete10_2_2_dag1;;

Format.printf "ordonnanceur_heterogene 10.0 2 2 dag2;;\n";;
TestProjet.affiche_trace ordohete10_2_2_dag2;;
TestProjet.verif_ordo_heterogene 10.0 2 2 dag2 ordohete10_2_2_dag2;;

Format.printf "ordonnanceur_heterogene 10.0 2 2 dag3;;\n";;
TestProjet.affiche_trace ordohete10_2_2_dag3;;
TestProjet.verif_ordo_heterogene 10.0 2 2 dag3 ordohete10_2_2_dag3;;

Format.printf "ordonnanceur_heterogene 10.0 2 2 dag4;;\n";;
TestProjet.affiche_trace ordohete10_2_2_dag4;;
TestProjet.verif_ordo_heterogene 10.0 2 2 dag4 ordohete10_2_2_dag4;;


let ordoheteq10_2_2_dag1 = ordonnanceur_heterogene_quick 10.0 2 2 (Dag.Dag.copy dag1);;
let ordoheteq10_2_2_dag2 = ordonnanceur_heterogene_quick 10.0 2 2 (Dag.Dag.copy dag2);;
let ordoheteq10_2_2_dag3 = ordonnanceur_heterogene_quick 10.0 2 2 (Dag.Dag.copy dag3);;
let ordoheteq10_2_2_dag4 = ordonnanceur_heterogene_quick 10.0 2 2 (Dag.Dag.copy dag4);;

Format.printf "Ordonnancement hétérogène pondéré avec accélération\n";;
Format.printf "ordonnanceur_heterogene_quick 10.0 2 2 dag1;;\n";;
TestProjet.affiche_trace ordoheteq10_2_2_dag1;;
TestProjet.verif_ordo_heterogene 10.0 2 2 dag1 ordoheteq10_2_2_dag1;;
TestProjet.faster ordohete10_2_2_dag1 ordoheteq10_2_2_dag1;;

Format.printf "ordonnanceur_heterogene_quick 10.0 2 2 dag2;;\n";;
TestProjet.affiche_trace ordoheteq10_2_2_dag2;;
TestProjet.verif_ordo_heterogene 10.0 2 2 dag2 ordoheteq10_2_2_dag2;;
TestProjet.faster ordohete10_2_2_dag2 ordoheteq10_2_2_dag2;;

Format.printf "ordonnanceur_heterogene_quick 10.0 2 2 dag3;;\n";;
TestProjet.affiche_trace ordoheteq10_2_2_dag3;;
TestProjet.verif_ordo_heterogene 10.0 2 2 dag3 ordoheteq10_2_2_dag3;;
TestProjet.faster ordohete10_2_2_dag3 ordoheteq10_2_2_dag3;;

Format.printf "ordonnanceur_heterogene_quick 10.0 2 2 dag4;;\n";;
TestProjet.affiche_trace ordoheteq10_2_2_dag4;;
TestProjet.verif_ordo_heterogene 10.0 2 2 dag4 ordoheteq10_2_2_dag4;;
TestProjet.faster ordohete10_2_2_dag4 ordoheteq10_2_2_dag4;;

