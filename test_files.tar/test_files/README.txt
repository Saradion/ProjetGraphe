Afin d'éxecuter le code de vérification de votre projet, veuillez suivre les étapes suivantes :

1)  Rassemblez les fonctions demandées (tri_topologique, ordonnanceur_multi, ordonnanceur_heterogene, ordonnanceur_heterogene_quick) dans un fichier nommé projet.ml
2)  Assurez-vous que les méthodes de graphe ne sont pas précédées de "Dag." . Par exemple, "Dag.fold_vertex" devient "fold_vertex". (Astuce : sous vim ou gvim, taper la commande ":%s/Dag.//g" retirera toutes les occurences de "Dag.")
3)  Retirez toutes les lignes du type "#use ..." et "#load ..." de ce fichier
4)  Ajoutez la ligne "open Dag.Dag;;" au début de ce fichier
5)  Placez le fichier projet.ml dans le dossier test_files/ obtenu par décompression du fichier moodle
6)  Si vous n'avez pas fait certaines fonctions, déclarez-les avec pour valeur de retour une liste vide (ex: "let ordonnanceur_heterogene_quick alpha r1 r2 dag = [];;")
7)  En vous plaçant dans ce dossier, tapez make
8)  S'il y a des erreurs de compilation, corrigez (then goto 6) )
9)  Renommez le fichier res.txt avec vos noms & groupes respectifs
10) Uploadez le fichier sur moodle
